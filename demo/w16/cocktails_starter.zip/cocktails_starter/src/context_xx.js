import React, { useState, useContext, useEffect } from 'react';
import { useCallback } from 'react';

const url = 'https://www.thecocktaildb.com/api/json/v1/1/search.php?s=';
const AppContext_xx = React.createContext();

const AppProvider_xx = ({ children }) => {
  return (
    <AppContext_xx.Provider value='hello'>{children}</AppContext_xx.Provider>
  );
};

export const useGlobalContext = () => {
  return useContext(AppContext_xx);
};

export { AppContext_xx, AppProvider_xx };
