import React from 'react';

const About_xx = () => {
  return (
    <div>
      <h2>about page</h2>
    </div>
  );
};

export default About_xx;
