import React from 'react';
import CocktailList_xx from '../components/CocktailList_xx';
import SearchForm_xx from '../components/SearchForm_xx';

const Home_xx = () => {
  return (
    <div>
      <h2>home page</h2>
    </div>
  );
};

export default Home_xx;
