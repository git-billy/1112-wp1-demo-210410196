import React from 'react';

const Loading_xx = () => {
  return <div className='loader'></div>;
};

export default Loading_xx;
