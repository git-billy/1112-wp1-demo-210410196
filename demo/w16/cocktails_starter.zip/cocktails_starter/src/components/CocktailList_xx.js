import React from 'react';
import Cocktail from './Cocktail_xx';
import Loading from './Loading_xx';
import { useGlobalContext } from '../context_xx';

const CocktailList_xx = () => {
  return (
    <div>
      <h2>cocktail list component</h2>
    </div>
  );
};

export default CocktailList_xx;
