import React from 'react';
import { useGlobalContext } from '../context_xx';

const SearchForm_xx = () => {
  return (
    <div>
      <h2>search form component</h2>
    </div>
  );
};

export default SearchForm_xx;
